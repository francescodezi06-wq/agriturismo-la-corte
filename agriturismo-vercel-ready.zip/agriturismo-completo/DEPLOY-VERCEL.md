# Pubblicazione su Vercel

## Configurazione inclusa
- `vite.config.ts` usa il plugin Nitro per il deploy full-stack su Vercel e mantiene l'entry server personalizzata.
- `vercel.json` indica esplicitamente il framework TanStack Start.
- `.env.example` elenca le variabili d'ambiente individuate nel codice.

## Prima del deploy
1. Caricare l'intera cartella del progetto in un repository GitHub privato.
2. Importare il repository da https://vercel.com/new.
3. Lasciare che Vercel rilevi TanStack Start; usare `npm run build` se chiede un comando di build.
4. Impostare le variabili d'ambiente indicate sotto in Vercel > Project > Settings > Environment Variables.
5. Fare Deploy e verificare home, pagine interne e invio richieste.

## Variabili d'ambiente

Obbligatorie per il client Supabase inizializzato in `src/integrations/supabase/client.ts`:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY` (lette anche dal middleware di autenticazione server)

Per la funzione server `createBooking` in `src/lib/bookings.functions.ts`:
- `SUPABASE_SERVICE_ROLE_KEY` (segreto: non usare mai il prefisso `VITE_`)

Per il helper SMTP Gmail in `src/lib/email-templates/send-email.ts`:
- `GMAIL_USER`
- `GMAIL_APP_PASSWORD`
- `ADMIN_EMAIL` (facoltativa)

Nota: il form della pagina `/camere` attualmente invia tramite EmailJS con identificativi pubblici incorporati nel codice. Il helper Nodemailer/Gmail è presente ma `createBooking` non risulta richiamata dai componenti esaminati. Prima della messa online va deciso un unico flusso di prenotazione e verificato che le email arrivino davvero. Le chiavi Supabase e Gmail non sono incluse in questo archivio: vanno recuperate dal progetto Supabase/Google e inserite come variabili su Vercel.

## Dominio
Dopo il primo deploy: Vercel > Project > Settings > Domains > Add Domain. Acquistare il dominio presso un registrar (es. Aruba) e copiare esattamente i record DNS mostrati da Vercel. Non impostare record DNS a intuito.

## Nota sicurezza
Non committare `.env`, password Gmail o la chiave Supabase `service_role`. Il file `.env.example` contiene solo segnaposto.
